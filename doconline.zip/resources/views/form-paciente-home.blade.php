<x-front-form-layout>
    <livewire:front.form-paciente-home :pacienteId="0"/>

</x-front-form-layout>
