<img src="{{asset('img/favicon.png')}}" width="80"/>
