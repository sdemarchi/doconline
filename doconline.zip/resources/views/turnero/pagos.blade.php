<x-turnero-layout>
    
    <livewire:turnero.pagos />

</x-turnero-layout>
