<x-turnero-layout>
    
    <livewire:turnero.confirmar />

</x-turnero-layout>
