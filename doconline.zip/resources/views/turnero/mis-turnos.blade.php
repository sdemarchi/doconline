<x-turnero-layout>
    
    <livewire:turnero.mis-turnos />

</x-turnero-layout>
