<x-turnero-layout>
    
    <livewire:turnero.confirmado />

</x-turnero-layout>
