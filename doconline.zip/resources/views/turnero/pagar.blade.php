<x-turnero-layout>
    
    <livewire:turnero.pagar :medioPago="$medio" :statusPago="$result"/>

</x-turnero-layout>
