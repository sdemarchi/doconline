<x-turnero-layout>
    
    <livewire:turnero.datos />

</x-turnero-layout>
