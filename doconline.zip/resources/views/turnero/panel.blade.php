<x-turnero-layout>
    
    <livewire:turnero.panel />

</x-turnero-layout>
