<x-turnero-layout>
    
    <livewire:turnero.turnos />

</x-turnero-layout>
