<x-turnero-layout>
    
    <livewire:front.grow-registrado />

</x-turnero-layout>
