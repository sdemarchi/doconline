<div class="page pt-5">
    <div class="container py-4">
      <div class="text-center mb-4">
        <a href="#"><img src="{{asset('img/logo-doconline-b-500.png')}}" width="300" /></a>
      </div>
      <div class="text-center mb-4">
        <h1>Registro de Grow</h1>
      </div>
      <div class="card card-md">
        <div class="card-body">
          <h2>Su Grow fue registrado correctamente</h2>
          <h4>Muchas Gracias</h4>
  
          <div class="form-footer">
            <a class="btn btn-primary" href="{{ route('grow') }}">Volver al Formulario de Registro</a>
           
  
          </div>
        </div>
  
      </div>
  
    </div>
  </div>