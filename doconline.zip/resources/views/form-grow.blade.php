<x-front-form-layout>
    <livewire:front.form-grow />

</x-front-form-layout>
