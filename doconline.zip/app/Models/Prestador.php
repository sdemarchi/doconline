<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Prestador extends Model
{
    public $timestamps = false;
    protected $table = "turn_prestadores";

}
