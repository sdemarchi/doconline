<?php

namespace App\Http\Livewire\Front;

use Livewire\Component;

class GrowRegistrado extends Component
{
    public function render()
    {
        return view('livewire.front.grow-registrado');
    }
}
