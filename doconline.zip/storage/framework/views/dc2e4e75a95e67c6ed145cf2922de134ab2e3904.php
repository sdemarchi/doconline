<div class="row row-cards">
    <div class="col-12">
        <div class="card">
            <div class="card-body border-bottom pt-3 pb-4">

                <div class="row">
                    <div class="col-md-4 col-sm-5 mt-1">
                        <select class="form-select" wire:model="prestadorId">
                            <option value="0">Seleccione Prestador</option>
                            <?php $__currentLoopData = $prestadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($prestador->id); ?>"><?php echo e($prestador->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

            </div>
            <div class="table-responsive">
                <table class="table table-vcenter card-table">
                    <thead>
                        <tr>
                            <th>Día</th>
                            <th>Desde</th>
                            <th>Hasta</th>
                            <th>Durac. Turno (min)</th>
                            <th width="30"></th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <select class="form-select" wire:model="diaAgregar">
                                    <option value="">Seleccione Día</option>
                                    <option value="1">Lunes</option>
                                    <option value="2">Martes</option>
                                    <option value="3">Miércoles</option>
                                    <option value="4">Jueves</option>
                                    <option value="5">Viernes</option>
                                    <option value="6">Sábado</option>
                                    <option value="7">Domingo</option>
                                </select>
                                <?php $__errorArgs = ['diaAgregar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                                <input type="time" class="form-control" wire:model.defer="desdeAgregar">
                                <?php $__errorArgs = ['desdeAgregar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                                <input type="time" class="form-control" wire:model.defer="hastaAgregar">
                                <?php $__errorArgs = ['hastaAgregar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                                <input type="text" class="form-control" wire:model.defer="duracionTurno">
                                <?php $__errorArgs = ['duracionTurno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                                <button class="btn btn-outline-primary" wire:click="configurarDia">Añadir</button></td>

                            </td>
                            
                        </tr>
                        <?php $__currentLoopData = $dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($dia->dia()); ?></td>
                            <td><?php echo e($dia->hora_desde); ?></td>
                            <td><?php echo e($dia->hora_hasta); ?></td>
                            <td><?php echo e($dia->duracion_turno); ?> minutos</td>
                            <td class="ps-2 p-0">
                                <button class="btn btn-ghost-light btn-icon"
                                    wire:click="$emit('triggerDelete',<?php echo e($dia->id); ?>)">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                        viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                        stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                        <line x1="4" y1="7" x2="20" y2="7" />
                                        <line x1="10" y1="11" x2="10" y2="17" />
                                        <line x1="14" y1="11" x2="14" y2="17" />
                                        <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" />
                                        <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" />
                                    </svg>
                                </button>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function () {
            window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerDelete', itemId => {
                Swal.fire({
                    title: 'Está Seguro?',
                    text: 'Se inhabilitarán los turnos para ese día',
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: '#ec536c',
                    cancelButtonColor: '#aaa',
                    cancelButtonText: 'cancelar',
                    confirmButtonText: 'Eliminar!'
                }).then((result) => {
            //if user clicks on delete
                    if (result.value) {
                
                        window.livewire.find('<?php echo e($_instance->id); ?>').call('eliminarItem',itemId)
                
                    }
                });
            });
        })
</script>

<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\doconline\resources\views/livewire/turnero/backend/turno-config.blade.php ENDPATH**/ ?>