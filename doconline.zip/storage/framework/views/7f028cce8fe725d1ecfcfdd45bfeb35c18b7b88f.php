<div class="page pt-5">
    <div class="container-tight container-datos py-4">
      <div class="text-center mb-4">
        <a href="#"><img src="<?php echo e(asset('img/logo-doconline-b-500.png')); ?>" width="300"/></a>
      </div>
      <div class="text-center mb-4">
        <h1>Turnos Online</h1>
      </div>
      <div class="card card-md">
        <div class="card-body">
          <h2 class="card-title text-center mb-4">Completá tus Datos</h2>
          <div class="row">
            <div class="mb-3 col-sm-6">
              <label class="form-label">DNI</label>
              <input type="text" class="form-control" wire:model.defer="paciente.dni">
              <?php $__errorArgs = ['paciente.dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 col-sm-6">
              <label class="form-label">Fecha de Nacimiento</label>
              <input type="date" class="form-control" width="25" wire:model.defer="paciente.fecha_nac">
              <?php $__errorArgs = ['paciente.fecha_nac'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-3 col-sm-12">
            <label class="form-label">Nombre y Apellido</label>
            <input type="text" class="form-control" placeholder="" wire:model.defer="paciente.nombre">
            <?php $__errorArgs = ['paciente.nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <!--<div class="mb-3 col-sm-12">
            <label class="form-label">Domicilio</label>
            <input type="text" class="form-control" wire:model.defer="paciente.direccion">
            <?php $__errorArgs = ['paciente.direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>-->
          <div class="row">
            <div class="mb-1 col-sm-6">
              <label class="form-label">Celular</label>
              <input type="text" class="form-control" wire:model.defer="paciente.telefono">
              <?php $__errorArgs = ['paciente.telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-1 col-sm-6">
              <label class="form-label">Confirmá tu Celular</label>
              <input type="text" class="form-control" wire:model.defer="telefono_conf" id="tel-conf">
              <?php $__errorArgs = ['telefono_conf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <span>ESCRIBÍ TU NUMERO CON CARACTERÍSTICA, SIN 0 NI 15. NO SE ADMITEN PUNTOS, COMAS, GUIONES NI ESPACIOS</span>
          </div>
          
          <div class="row">
            <div class="mb-3 col-sm-6 mt-3">
              <label class="form-label">E-Mail</label>
              <input type="text" class="form-control" wire:model.defer="paciente.email">
              <?php $__errorArgs = ['paciente.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 col-sm-6 mt-3">
              <label class="form-label">Confirmá tu E-Mail</label>
              <input type="text" class="form-control" wire:model.defer="email_conf" id="email-conf">
              <?php $__errorArgs = ['email_conf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
            
          <div class="form-footer">
            <a  href="<?php echo e(route('turnero')); ?>" class="btn btn-secondary">Atrás </a>
            <button class="btn btn-primary" wire:click="guardar">Continuar</button>
          </div>
        </div>
      </div>
      
    </div>
  </div>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
  $(document).ready(function() {
      const confTel = document.getElementById('tel-conf');
      confTel.onpaste = e => e.preventDefault(); 
      const confEmail = document.getElementById('email-conf');
      confEmail.onpaste = e => e.preventDefault();   
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\doconline\resources\views/livewire/turnero/datos.blade.php ENDPATH**/ ?>