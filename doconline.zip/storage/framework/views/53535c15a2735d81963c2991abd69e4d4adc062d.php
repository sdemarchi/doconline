<div class="card">
    <div class="card-footer text-end">
        <div class="d-flex">
            <button class="btn btn-link" onclick="window.history.back();">Volver</button>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="mb-3 col-sm-6">
                <label class="form-label">Nombre y Apellido</label>
                <input type="text" class="form-control" placeholder="" wire:model.defer="paciente.nombre" disabled>
                <?php $__errorArgs = ['paciente.nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 col-sm-6">
              <label class="form-label">DNI</label>
              <input type="text" class="form-control" wire:model.defer="paciente.dni" disabled>
              <?php $__errorArgs = ['paciente.dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row">
            <div class="mb-3 col-sm-6">
              <label class="form-label">Fecha de Nacimiento</label>
              <input type="date" class="form-control" width="25" wire:model.defer="paciente.fecha_nac" disabled>
              <?php $__errorArgs = ['paciente.fecha_nac'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 col-sm-6">
                <label class="form-label">Domicilio</label>
                <input type="text" class="form-control" wire:model.defer="paciente.direccion" disabled>
                <?php $__errorArgs = ['paciente.direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row">
            <div class="mb-3 col-sm-6">
                <label class="form-label">Teléfono</label>
                <input type="text" class="form-control" wire:model.defer="paciente.telefono" disabled>
                <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
                <div class="mb-3 col-sm-6">
                <label class="form-label">E-Mail</label>
                <input type="text" class="form-control" wire:model.defer="paciente.email" disabled>
                <?php $__errorArgs = ['paciente.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

    </div>
</div><?php /**PATH C:\laragon\www\doconline\resources\views/livewire/turnero/backend/ficha-paciente.blade.php ENDPATH**/ ?>