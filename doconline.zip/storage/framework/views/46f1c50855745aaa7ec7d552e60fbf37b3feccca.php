<?php if (isset($component)) { $__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TurneroLayout::class, []); ?>
<?php $component->withName('turnero-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('turnero.login', [])->html();
} elseif ($_instance->childHasBeenRendered('1T6XZ5L')) {
    $componentId = $_instance->getRenderedChildComponentId('1T6XZ5L');
    $componentTag = $_instance->getRenderedChildComponentTagName('1T6XZ5L');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1T6XZ5L');
} else {
    $response = \Livewire\Livewire::mount('turnero.login', []);
    $html = $response->html();
    $_instance->logRenderedChild('1T6XZ5L', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b)): ?>
<?php $component = $__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b; ?>
<?php unset($__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\doconline\resources\views/turnero/login.blade.php ENDPATH**/ ?>