<?php if (isset($component)) { $__componentOriginal5bd481258f37b63a10501ed0f37afe9f68b640d8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontFormLayout::class, []); ?>
<?php $component->withName('front-form-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.form-grow', [])->html();
} elseif ($_instance->childHasBeenRendered('ZxM9Tnu')) {
    $componentId = $_instance->getRenderedChildComponentId('ZxM9Tnu');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZxM9Tnu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZxM9Tnu');
} else {
    $response = \Livewire\Livewire::mount('front.form-grow', []);
    $html = $response->html();
    $_instance->logRenderedChild('ZxM9Tnu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bd481258f37b63a10501ed0f37afe9f68b640d8)): ?>
<?php $component = $__componentOriginal5bd481258f37b63a10501ed0f37afe9f68b640d8; ?>
<?php unset($__componentOriginal5bd481258f37b63a10501ed0f37afe9f68b640d8); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\doconline\resources\views/form-grow.blade.php ENDPATH**/ ?>