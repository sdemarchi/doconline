<head>
    
    <style>
    body {
        background-image: url(<?php echo e(asset("/img/formularios/consentimiento1.jpg")); ?>);
        background-repeat: no-repeat;
        background-size: 21cm;
        color: #000;
    }

    .page2{
        background-image: url(<?php echo e(asset("/img/formularios/consentimiento2.jpg")); ?>);
        background-size: 21cm;
        color: #000;
    }

    html {
        margin: 0px;
        padding: 0px;
    }
    
    .bloque {
        position: absolute;
        line-height: 18.6px;
        font-family: "Poppins", sans-serif;
        font-size: 12px;
    }

    .bloque1{
        top: 107px;
        left: 50px;
    }

    .bloque2{
        top: 330px;
        left: 70px;
    }

    .bloque3{
        top: 462px;
        left: 210px;
    }

    .bloque4{
        top: 620px;
        left: 70px;
    }

    .page_break { page-break-before: always; }

    </style>
    </head>
    
    <body>
    
        <div class="bloque bloque1">
            <span style="position: fixed; left: 170px"><?php echo e($paciente->nom_ape); ?></span>
            <span style="position: fixed; left: 555px"> <?php echo e($paciente->dni); ?></span> <br/>
            <span style="position: fixed; left: 200px"> <?php echo e($paciente->domicilio); ?></span> <br/>
            <?php if($paciente->es_menor): ?>
                <span style="position: fixed; left: 240px"> <?php echo e($paciente->tut_apeynom); ?></span>
            <?php endif; ?>
            <br/>
            <span style="position: fixed; left: 440px"> <?php echo e($medico->apeynom); ?></span> <br/>
            <span style="position: fixed; left: 127px"> <?php echo e($medico->matricula); ?></span>
            <span style="position: fixed; left: 290px"> <?php echo e($medico->domicilio); ?></span> <br/>
        
        </div>

        <div class="bloque bloque2">
            <span><?php echo e($paciente->diagnostico); ?></span>
        </div>

        <div class="bloque bloque3">
            <span><?php echo e($paciente->cant_plantas); ?> plantas</span><br/>
            <span><?php echo e($paciente->dosis); ?></span><br/>
            <span><?php echo e($paciente->conc_thc); ?>%</span><br/>
            <span><?php echo e($paciente->conc_cbd); ?>%</span><br/>
            <span><?php echo e($paciente->frecuencia); ?></span><br/>
        </div>
        
        <div class="bloque bloque4">
            <span><?php echo e($paciente->beneficios); ?></span>
        </div>

        <div style="position: relative; left: 80px; top: 700px">
            <img src="<?php echo e(asset('/img/uploads/' . $medico->firma)); ?>" height="80" />
        </div>
        <?php if($paciente->foto_firma): ?>
            <div style="position: relative; left: 70px; top: 760px">
                <img src="<?php echo e(asset('/img/uploads/' . $paciente->foto_firma)); ?>" height="80" />
            </div>
        <?php else: ?>
            <div style="position: relative; left: 50px; top: 775px;">
                <img style="max-width:140px; max-height:130px" src="<?php echo e($paciente->firma_v2); ?>" />
            </div>
            <div style="position: relative; left: 210px; top: 700px;">
                <img style="max-width:140px; max-height:130px" src="<?php echo e($paciente->aclaracion_v2); ?>" />
            </div>
        <?php endif; ?>
    

    

        
    
    </body>
    <body class="page2">
        <div class="bloque" style="position: fixed; left: 470px; top: 689px">
            <span>Santa Fe &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($dia); ?></span><br/>
        </div>
        <div class="bloque" style="position: fixed; left: 80px; top: 708px">
            <span><?php echo e($mes); ?> </span><span style="position: fixed; left: 233px;"><?php echo e($anio); ?></span>
        </div>
        
        <div style="position: relative; left: 80px; top: 735px">
            <img src="<?php echo e(asset('/img/uploads/' . $medico->firma)); ?>" height="80" />
        </div>
        <?php if($paciente->foto_firma): ?>
            <div style="position: relative; left: 70px; top: 770px">
                <img src="<?php echo e(asset('/img/uploads/' . $paciente->foto_firma)); ?>" height="80" />
            </div>
        <?php else: ?>
            <div style="position: relative; left: 50px; top: 800px">
                <img src="<?php echo e($paciente->firma_v2); ?>" width="140" />
            </div>
            <div style="position: relative; left: 210px; top: 745px">
                <img src="<?php echo e($paciente->aclaracion_v2); ?>" width="140" />
            </div>
        <?php endif; ?>
        
    

    
    </body>

    <?php /**PATH C:\laragon\www\doconline\resources\views/pdf/consentimiento.blade.php ENDPATH**/ ?>