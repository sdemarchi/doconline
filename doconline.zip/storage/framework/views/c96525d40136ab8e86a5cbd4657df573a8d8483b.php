<?php if (isset($component)) { $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BackendLayout::class, []); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Editar Ingreso
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12" style="width:auto !important; max-width:none !important;">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 border-b border-gray-200">
                   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('usuarios.usuario-ingreso-edit', ['registroId' => $id])->html();
} elseif ($_instance->childHasBeenRendered('yBJd7P0')) {
    $componentId = $_instance->getRenderedChildComponentId('yBJd7P0');
    $componentTag = $_instance->getRenderedChildComponentTagName('yBJd7P0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yBJd7P0');
} else {
    $response = \Livewire\Livewire::mount('usuarios.usuario-ingreso-edit', ['registroId' => $id]);
    $html = $response->html();
    $_instance->logRenderedChild('yBJd7P0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c)): ?>
<?php $component = $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c; ?>
<?php unset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\doconline\resources\views/backend/usuarios/usuario-ingreso-edit.blade.php ENDPATH**/ ?>