<div class="page pt-5">
    <div class="container-tight container-login py-4">
      <div class="text-center mb-4">
        <a href="#"><img src="<?php echo e(asset('img/logo-doconline-b-500.png')); ?>" width="300"/></a>
      </div>
      <div class="text-center mb-4">
        <h1>Turnos Online</h1>
      </div>
      <div class="card card-md">
        <div class="card-body">
          <h2 class="card-title text-center mb-4">Ingresá tus Datos</h2>
          <div class="row">
            <div class="mb-3 col-sm-6">
              <label class="form-label">DNI</label>
              <input type="text" class="form-control" placeholder="Ingresá tu DNI" wire:model.defer="dni">
              <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 col-sm-6">
              <label class="form-label">Fecha de Nacimiento</label>
              <input type="date" class="form-control" width="25" wire:model.defer="fecha_nac">
              <?php $__errorArgs = ['fecha_nac'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          
          
          <div class="form-footer text-center">
            <div class="col">
              <button class="btn btn-primary px-5" wire:click="ingresar">Iniciá Sesión</button>
              <a class="btn login-with-google-btn" href="<?php echo e(route('google.login')); ?>">
                Ingresá con Google
              </a>
              </div>
            
            
          </div>
        </div>
      </div>
      
    </div>
  </div><?php /**PATH C:\laragon\www\doconline\resources\views/livewire/turnero/login.blade.php ENDPATH**/ ?>