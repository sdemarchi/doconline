<head>
    
    <style>
    body {
        background: url(<?php echo e(asset("/img/formularios/declaracion.png")); ?>);
        background-size: 21cm;
        color: #000;
    }

    html {
        margin: 0px;
        padding: 0px;
    }
    
    .bloque {
        position: absolute;
        line-height: 17.3px;
        font-family: "Poppins", sans-serif;
        font-size: 11px;
    }

    .bloque1{
        top: 174px;
        left: 150px;
    }

    .bloque2{
        top: 353px;
        left: 150px;
    }

    .bloque3{
        top: 532px;
        left: 150px;
    }

    .bloque4{
        top: 691px;
        left: 459px;
        line-height: 20px;
    }

    .bloque5{
        top: 776px;
        left: 459px;
        line-height: 24px;
    }

    .bloque6{
        top: 898px;
        left: 50px;
        line-height: 16px;
        
    }

    .bloque7{
        top: 1050px;
        left: 80px;
    }
    </style>
    </head>
    <body>
        
        <div class="bloque bloque1">
            <span><?php echo e($paciente->nom_ape); ?></span> <br/>
            <span>DNI <?php echo e($paciente->dni); ?></span> <span style="position: fixed; left: 450px"> <?php echo e(date_format(date_create($paciente->fe_nacim),"d/m/Y")); ?></span> <br/>
            <span> <?php echo e($paciente->domicilio); ?></span> <br/>
            <span> <?php echo e($paciente->localidad); ?></span><span style="position: fixed; left: 450px"> <?php echo e($paciente->provincia->Provincia); ?> </span>
            <span style="position: fixed; left: 620px"> <?php echo e($paciente->cp); ?></span>  <br/>
            <span style="position: fixed; left: 450px"> <?php echo e($paciente->celular); ?></span> <br/>
            <span> <?php echo e($paciente->email); ?></span> <br/>
            <span> <?php echo e($paciente->osocial); ?></span> <br/>
        </div>
        
        <?php if($paciente->es_menor): ?>
        <div class="bloque bloque2">
            <span><?php echo e($paciente->tut_apeynom); ?></span> <span style="position: fixed; left: 430px"><?php echo e($paciente->tut_tipo_nro_doc); ?></span>
                <span style="position: fixed; left: 620px"> <?php echo e(date_format(date_create($paciente->tut_fe_nacim),"d/m/Y")); ?></span>  <br/>
            <span style="position: fixed; left: 100px"><?php echo e($paciente->tut_domicilio); ?></span><span style="position: fixed; left: 380px"><?php echo e($paciente->tut_localidad); ?></span> 
                <span style="position: fixed; left: 510px"><?php echo e($paciente->tut_provincia->Provincia); ?></span><span style="position: fixed; left: 620px"><?php echo e($paciente->tut_cp); ?></span><br/>
            <span style="position: fixed; left: 300px"><?php echo e($paciente->tut_vinculo); ?></span> <br/>
            <span><?php echo e($paciente->tut_tel_part); ?></span> <span style="position: fixed; left: 450px"><?php echo e($paciente->tut_tel_cel); ?></span><br/>
            <span><?php echo e($paciente->tut_mail); ?></span> <br/>
            <span><?php echo e($paciente->tut_osocial); ?></span> <br/>
            <?php if($paciente->tut_reg_fam): ?>
            <span style="position: fixed; left: 285px">x</span> <br/>
            
            <?php else: ?>
            <span style="position: fixed; left: 368px">x</span> <br/>
            
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <div class="bloque bloque3">
            <span><?php echo e($medico->apeynom); ?></span> <span style="position: fixed; left: 550px"><?php echo e($medico->tipo_nro_doc); ?></span><br/>
            <span><?php echo e($medico->matricula); ?></span> <span style="position: fixed; left: 380px"><?php echo e($medico->especialidad); ?></span><br/>
            <span style="position: fixed; left: 205px"><?php echo e($medico->tel_part); ?></span> <span style="position: fixed; left: 450px"><?php echo e($medico->tel_cel); ?></span><br/>
            <span style="position: fixed; left: 205px"><?php echo e($medico->email); ?></span> <br/>
            <span style="position: fixed; left: 185px; padding-right:25px; line-height:16.9px"><?php echo e($paciente->res_historia); ?></span> <br/>
        </div>

        <div class="bloque bloque4">
            <?php if(!$paciente->arritmia): ?><span>x</span><?php else: ?><span style="position: fixed; left: 495px">x</span><?php endif; ?><br/>
            <?php if(!$paciente->salud_mental): ?><span>x</span><?php else: ?><span style="position: fixed; left: 495px">x</span><?php endif; ?><br/>
            <?php if($paciente->salud_mental): ?><span style="position: fixed; top:557; left: 180px"><?php echo e($paciente->salud_ment_esp); ?></span><?php endif; ?><br/>
        </div>

        <div class="bloque bloque5">
            <?php if(!$paciente->alergia): ?><span>x</span><?php else: ?><span style="position: fixed; left: 495px">x</span><?php endif; ?><br/>
            <?php if(!$paciente->embarazada): ?><span style="position: fixed; top: 802px">x</span><?php else: ?><span style="position: fixed; top: 802px; left: 495px">x</span><?php endif; ?><br/>
            <?php if(!$paciente->maneja_maq): ?><span>x</span><?php else: ?><span style="position: fixed; left: 495px">x</span><?php endif; ?><br/>
        </div>

        <span class="bloque" style="position: fixed; left: 120px; top: 847px"><?php echo e($paciente->diagnostico); ?></span>

        <div class="bloque bloque6">
            <span><?php echo e($paciente->justificacion); ?></span><br/>
            <span><?php echo e($paciente->tratam_previo); ?></span><br/>
            <span><?php echo e($paciente->producto_indicado); ?></span><br/>
        </div>
        
        <div style="position: fixed; left: 40px; top: 960px">
            <img src="<?php echo e(asset('/img/uploads/' . $medico->firma)); ?>" height="60" />
        </div>
        <div style="position: fixed; left: 305px; top: 956px">
            <img src="<?php echo e(asset('/img/uploads/' . $medico->sello)); ?>" height="70" />
        </div>
        <?php if($paciente->foto_firma): ?>
            <div style="position: fixed; left: 540px; top: 960px">
                <img src="<?php echo e(asset('/img/uploads/' . $paciente->foto_firma)); ?>" height="60" />
            </div>
        <?php else: ?>
            <div style="position: fixed; left: 500px; top: 970px">
                <img src="<?php echo e($paciente->firma_v2); ?>" height="70" />
            </div>
            <div style="position: fixed; left: 640px; top: 970px">
                <img src="<?php echo e($paciente->aclaracion_v2); ?>" height="70" />
            </div>
        <?php endif; ?>
        

        <div class="bloque bloque7">
            <span>Santa Fe&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(date_format(date_create($paciente->fe_carga),"d/m/Y")); ?></span>
            <span style="position: fixed; left: 600px">Santa Fe&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(date_format(date_create($paciente->fe_carga),"d/m/Y")); ?></span><br/>
        </div>
    </body>
    <?php /**PATH C:\laragon\www\doconline\resources\views/pdf/declaracion.blade.php ENDPATH**/ ?>