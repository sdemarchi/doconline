<?php if (isset($component)) { $__componentOriginalf5302f8d9d4888814441d6c8cf3eb2dcc5b1c16c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontendLayout::class, []); ?>
<?php $component->withName('frontend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        
     <?php $__env->endSlot(); ?>
    <div class="page pt-5">
    <div class="container-tight container-login py-4">
      <div class="card card-md">
        <div class="card-body mb-4">
            <h2 class="text-center mb-4">Datos Guardados</h2>
            <h4 class="text-center">Los datos ingresados se guardaron con éxito</h4>
        </div>
      </div>
      <div class="form-footer text-center">
        <a class="btn btn-primary" href="<?php echo e(route('turnero.panel')); ?>">Volver al Inicio</a>
      </div>  
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf5302f8d9d4888814441d6c8cf3eb2dcc5b1c16c)): ?>
<?php $component = $__componentOriginalf5302f8d9d4888814441d6c8cf3eb2dcc5b1c16c; ?>
<?php unset($__componentOriginalf5302f8d9d4888814441d6c8cf3eb2dcc5b1c16c); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\doconline\resources\views/formulario-guardado.blade.php ENDPATH**/ ?>