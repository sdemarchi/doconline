<div class="row row-cards">
    <div class="col-12">
      <div class="card">
        <div class="card-body border-bottom py-3">
          <div class="d-flex">
            <div class="ms-auto text-muted">
              <div class="ms-2 d-inline-block">
                <input type="text" class="form-control form-control-sm" placeholder="Buscar Paciente"
                wire:model.defer="searchString" wire:keydown.enter="resetPagination">
              </div>
            </div>
          </div>
        </div>
        <div class="table-responsive">
          <table class="table table-vcenter card-table">
            <thead>
              <tr>
                <th>Id</th>
                <th>Nombre</th>
                <th>DNI</th>
                <th>Teléfono</th>
                <th>E-Mail</th>
                <th>Fecha Emisión</th>
                <th>Turno</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
  
              <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
  
                <td><?php echo e($paciente->id); ?></td>
                <td><?php echo e($paciente->nombre); ?></td>
                <td><?php echo e($paciente->dni); ?></td>
                <td><?php echo e($paciente->telefono); ?></td>
                <td><?php echo e($paciente->email); ?></td>
                <td><?php if($paciente->ultimo_turno()): ?>
                  <?php if($paciente->ultimo_turno()->fecha_emision): ?>  
                  <?php echo e(date_format(date_create($paciente->ultimo_turno()->fecha_emision),"d/m/Y")); ?>

                  <?php endif; ?>
                <?php endif; ?>
                </td>
                <td><?php if($paciente->ultimo_turno()): ?>
                  <span class="badge bg-blue"><?php echo e(date_format(date_create($paciente->ultimo_turno()->fecha),"d/m/Y")); ?> <?php echo e($paciente->ultimo_turno()->hora); ?></span>
                  <?php endif; ?>
                </td>
                <td>
                  <div class="dropdown">
                    <button class="btn btn-sm btn-dark dropdown-toggle align-text-top" data-bs-boundary="viewport"
                      data-bs-toggle="dropdown">
                      Acciones
                    </button>
                    <div class="dropdown-menu dropdown-menu-end">
                       <button class="dropdown-item" wire:click="$emit('triggerDelete',<?php echo e($paciente->id); ?>)">
                          Eliminar
                        </button>
                    </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
            </tbody>
  
          </table>
          <?php echo e($pacientes->links()); ?>

        </div>
      </div>
    </div>
  </div>
  
  <?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {
            window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerDelete', itemId => {
                Swal.fire({
                    title: 'Está Seguro?',
                    text: 'Se eliminará el Paciente',
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: '#ec536c',
                    cancelButtonColor: '#aaa',
                    cancelButtonText: 'cancelar',
                    confirmButtonText: 'Eliminar!'
                }).then((result) => {
                    if (result.value) {
                
                        window.livewire.find('<?php echo e($_instance->id); ?>').call('eliminar',itemId)
                
                    }
                });
            });
        })
    </script>
  
  <?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\doconline\resources\views/livewire/turnero/backend/turno-pacientes.blade.php ENDPATH**/ ?>