<img src="<?php echo e(asset('img/favicon.png')); ?>" width="80"/>
<?php /**PATH C:\laragon\www\doconline\resources\views/components/application-logo.blade.php ENDPATH**/ ?>