<?php if (isset($component)) { $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BackendLayout::class, []); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Formulario Web
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12" style="width:auto !important; max-width:none !important;">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('web-reprocann', [])->html();
} elseif ($_instance->childHasBeenRendered('CD4YR0v')) {
    $componentId = $_instance->getRenderedChildComponentId('CD4YR0v');
    $componentTag = $_instance->getRenderedChildComponentTagName('CD4YR0v');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CD4YR0v');
} else {
    $response = \Livewire\Livewire::mount('web-reprocann', []);
    $html = $response->html();
    $_instance->logRenderedChild('CD4YR0v', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>

   
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c)): ?>
<?php $component = $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c; ?>
<?php unset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\doconline\resources\views/backend/web-reprocann.blade.php ENDPATH**/ ?>