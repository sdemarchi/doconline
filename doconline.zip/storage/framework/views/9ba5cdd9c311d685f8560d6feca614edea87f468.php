<?php if (isset($component)) { $__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TurneroLayout::class, []); ?>
<?php $component->withName('turnero-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.grow-registrado', [])->html();
} elseif ($_instance->childHasBeenRendered('JmaYRVD')) {
    $componentId = $_instance->getRenderedChildComponentId('JmaYRVD');
    $componentTag = $_instance->getRenderedChildComponentTagName('JmaYRVD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JmaYRVD');
} else {
    $response = \Livewire\Livewire::mount('front.grow-registrado', []);
    $html = $response->html();
    $_instance->logRenderedChild('JmaYRVD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b)): ?>
<?php $component = $__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b; ?>
<?php unset($__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\doconline\resources\views/grow-registrado.blade.php ENDPATH**/ ?>