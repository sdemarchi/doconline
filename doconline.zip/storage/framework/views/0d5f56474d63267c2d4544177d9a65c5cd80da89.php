<div class="row row-cards">
    <div class="col-12">
        <div class="card">
            <div class="table-responsive">
                <table class="table table-vcenter card-table">
                    <thead>
                        <tr>
                            <th width="30"></th>
                            <th width="50">Id</th>
                            <th>Código</th>
                            <th>Descripción</th>
                            <th width="150">Descuento</th>
                            <th width="100">Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td colspan=2><button class="btn btn-outline-primary" wire:click="agregarCupon">Agregar</button></td>
                        <td>
                            <input type="text" class="form-control" wire:model.defer="cuponAgregar">
                            <?php $__errorArgs = ['cuponAgregar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                        <td>
                            <input type="text" class="form-control" wire:model.defer="descripcionAgregar">
                            <?php $__errorArgs = ['descripcionAgregar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                        <td>
                            <input type="text" class="form-control" wire:model.defer="descuentoAgregar">
                            <?php $__errorArgs = ['descuentoAgregar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $cupones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="ps-2 p-0">
                                <button class="btn btn-ghost-light btn-icon" wire:click="$emit('triggerDelete',<?php echo e($cupon->id); ?>)">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                        <line x1="4" y1="7" x2="20" y2="7" /><line x1="10" y1="11" x2="10" y2="17" /><line x1="14" y1="11" x2="14" y2="17" />
                                        <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" /><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" />
                                    </svg>
                                </button>
                            </td>
                            
                            <td><?php echo e($cupon->id); ?></td>
                            <td><?php echo e($cupon->codigo); ?></td>
                            <td><?php echo e($cupon->descripcion); ?></td>
                            <td class="text-end"><?php echo e(number_format($cupon->descuento, 2, ',', '.')); ?></td>
                            <td>
                                <?php if($cupon->activo): ?>
                                  <span class="btn badge bg-success me-1" wire:click="switch(<?php echo e($cupon->id); ?>,0)"></span>Activo
                                <?php else: ?>
                                  <span class="btn badge bg-danger me-1" wire:click="switch(<?php echo e($cupon->id); ?>,1)"></span>Inactivo
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                    
                </table>
                <?php echo e($cupones->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function () {
            window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerDelete', id => {
                Swal.fire({
                    title: 'Está Seguro?',
                    text: 'Se eliminará el Cupón',
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: '#ec536c',
                    cancelButtonColor: '#aaa',
                    cancelButtonText: 'cancelar',
                    confirmButtonText: 'Eliminar!'
                }).then((result) => {
            //if user clicks on delete
                    if (result.value) {
                
                        window.livewire.find('<?php echo e($_instance->id); ?>').call('eliminar',id)
                
                    }
                });
            });
        })
</script>
    
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\doconline\resources\views/livewire/cupones/cupones.blade.php ENDPATH**/ ?>