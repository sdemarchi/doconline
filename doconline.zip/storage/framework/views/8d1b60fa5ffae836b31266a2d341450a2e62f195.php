<div class="row row-cards">
    <div class="col-12">
      <div class="card">
        <div class="card-body border-bottom py-3">
          <div class="d-flex">
            <div class="ms-auto text-muted">
              <div class="ms-2 d-inline-block">
                <select class="form-select" wire:model="userId" wire:click="resetPagination">
                  <option value="0">Todos los Usuarios</option>
                  <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($usuario->id); ?>"><?php echo e($usuario->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
          </div>
        </div>
        <div class="table-responsive">
          <table class="table table-vcenter card-table">
            <thead>
              <tr>
                <th>Usuario</th>
                <th>Inicio</th>
                <th>Fin</th>
                <th>Liquidado</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
  
              <?php $__currentLoopData = $horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
  
                <td><?php echo e($hora->usuario->name); ?></td>
                <td><?php echo e(date_format(date_create($hora->inicio),"d/m/Y H:i")); ?></td>
                <td>
                    <?php if($hora->fin): ?>
                        <?php echo e(date_format(date_create($hora->fin),"d/m/Y H:i")); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($hora->liquidado): ?>
                        <span class="badge bg-success">Sí</span>
                    <?php else: ?>
                        <span class="badge bg-danger">No</span>
                    <?php endif; ?>
                </td>    
                <td>
                  <div class="dropdown">
                    <button class="btn btn-sm btn-dark dropdown-toggle align-text-top" data-bs-boundary="viewport"
                      data-bs-toggle="dropdown">
                      Acciones
                    </button>
                    <div class="dropdown-menu dropdown-menu-end">
                        <?php if($hora->liquidado): ?>
                            <button class="dropdown-item" wire:click="noLiquidado('<?php echo e($hora->id); ?>')">
                                No Liquidado
                            </button>
                        <?php else: ?>
                            <button class="dropdown-item" wire:click="liquidado('<?php echo e($hora->id); ?>')">
                                Liquidado
                            </button>
                        <?php endif; ?>
                        
                    </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
            </tbody>
  
          </table>
          <?php echo e($horas->links()); ?>

        </div>
      </div>
    </div>
  </div>
  <?php /**PATH C:\laragon\www\doconline\resources\views/livewire/horas-trabajadas.blade.php ENDPATH**/ ?>