<div class="page pt-5">
    <div class="container">
      <div class="text-center mb-4">
        <a href="#"><img src="<?php echo e(asset('img/logo-doconline-b-500.png')); ?>" width="300"/></a>
      </div>
      <div class="text-center mb-4">
        <h1>Turnos Online</h1>
      </div>
      <div class="card card-md">
        <div class="card-body">
            <h2 class="text-center mb-4">Nuevo Turno</h1>
            <div class="row">
              <div class="col-lg-4 col-md-6">
                <label class="form-label">Seleccioná Prestador</label>
                <?php $__currentLoopData = $prestadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="btn-pill btn-primary py-1 px-4" wire:click="prestadorSelect(<?php echo e($prestador->id); ?>)">
                    <?php echo e($prestador->nombre); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div <?php if(!$prestadorId): ?> style="display:none" <?php endif; ?> class="mt-2">
                        <h4 class="mt-4 mb-3">Seleccioná un Día (en verde los disponibles)</h4>
                        <button class ="item-calendario control-calendario" wire:click="mesAnterior">
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="15 6 9 12 15 18" /></svg>
                        </button>
                        <button class ="item-calendario titulo-calendario"><?php echo e($mesTexto); ?> <?php echo e($anioActual); ?></button>
                        <button class ="item-calendario control-calendario" wire:click="mesSiguiente">
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="9 6 15 12 9 18" /></svg>
                        </button>
                       <div>
                        <button class="encabez-calendario">dom.</button>
                        <button class="encabez-calendario">lun.</button>
                        <button class="encabez-calendario">mar.</button>
                        <button class="encabez-calendario">mie.</button>
                        <button class="encabez-calendario">jue.</button>
                        <button class="encabez-calendario">vie.</button>
                        <button class="encabez-calendario">sáb.</button>
                        
                       </div>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $calendario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php $i++; ?>
                          
                            <button class="item-calendario <?php echo e($dia['inactivo']); ?> <?php echo e($dia['enmes']); ?> <?php echo e($dia['turnos']); ?>" 
                            wire:click="fechaSelect('<?php echo e($dia['fecha']); ?>', '<?php echo e($dia['inactivo']); ?>')">
                              <?php echo e($dia['dia']); ?></button>
                          
                          <?php 
                            if($i == 7){
                              echo '<br/>';
                              $i = 0;
                            }
                          ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
                <div class="col-md-6">
                  <div <?php if(!$fechaSeleccionada): ?> style="display:none" <?php endif; ?> class="mt-2">
                    <h4 class="mt-4 mb-3">Seleccioná un Turno</h4>
                    <?php $__currentLoopData = $turnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button class="turno" wire:click="turnoSelect(<?php echo e($turno['id']); ?>)">
                      <?php echo e($turno['detalle']); ?></button><br/>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div> 
                   
                  
                </div>
            </div>
            <div class="form-footer">
              <a class="btn btn-secondary" href="<?php echo e(route('turnero.panel')); ?>">Atrás</a>
            </div>  
          </div>
        </div>
      </div>
      
    </div>
  </div><?php /**PATH C:\laragon\www\doconline\resources\views/livewire/turnero/turnos.blade.php ENDPATH**/ ?>