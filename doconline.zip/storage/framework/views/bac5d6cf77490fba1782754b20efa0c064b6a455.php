<?php if (isset($component)) { $__componentOriginal5bd481258f37b63a10501ed0f37afe9f68b640d8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontFormLayout::class, []); ?>
<?php $component->withName('front-form-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.form-paciente-home', ['pacienteId' => 0])->html();
} elseif ($_instance->childHasBeenRendered('ZQpps2k')) {
    $componentId = $_instance->getRenderedChildComponentId('ZQpps2k');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZQpps2k');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZQpps2k');
} else {
    $response = \Livewire\Livewire::mount('front.form-paciente-home', ['pacienteId' => 0]);
    $html = $response->html();
    $_instance->logRenderedChild('ZQpps2k', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bd481258f37b63a10501ed0f37afe9f68b640d8)): ?>
<?php $component = $__componentOriginal5bd481258f37b63a10501ed0f37afe9f68b640d8; ?>
<?php unset($__componentOriginal5bd481258f37b63a10501ed0f37afe9f68b640d8); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\doconline\resources\views/form-paciente-home.blade.php ENDPATH**/ ?>