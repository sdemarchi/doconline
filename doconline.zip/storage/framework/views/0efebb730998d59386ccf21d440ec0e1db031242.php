<div>  
  <div class="row row-cards">
    <div class="col-12">
      <div class="card">
        <div class="card-body border-bottom pt-3 pb-4">
          <div class="row">
            <div class="col">
              <h3>Horas trabajadas durante el mes</h3>
            </div>
            <div class="col-md-2 col-sm-3 mt-1">
              <select class="form-select" wire:model="mesActual" wire:click="refresh">
                <?php for($i=0;$i<12;$i++): ?>
                  <option value="<?php echo e($i+1); ?>"><?php echo e($meses[$i]); ?></option>
                <?php endfor; ?>
              </select>
              </div>
            <div class="col-md-2 col-sm-3 mt-1">
              <select class="form-select" wire:model="anioActual" wire:click="refresh">
                <?php for($i=$anioReferencia-10;$i<=$anioReferencia;$i++): ?>
                  <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                <?php endfor; ?>
              </select>
            </div>
          </div>
          

          <div class="table-responsive">
            <table class="table table-vcenter card-table">
              <thead>
                <tr>
                  <th>Usuario</th>
                  <th>Horas Trabajadas</th>

                </tr>
              </thead>
              <tbody>

                <?php $__currentLoopData = $usuariosHoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                  <td><?php echo e($usuario['nombre']); ?></td>
                  <td><?php echo e($usuario['horas']); ?></td>
                  <td>
                    <div class="dropdown">
                      <button class="btn btn-sm btn-dark dropdown-toggle align-text-top" data-bs-boundary="viewport"
                        data-bs-toggle="dropdown">
                        Acciones
                      </button>
                      <div class="dropdown-menu dropdown-menu-end">
                        <button class="dropdown-item" wire:click="liquidarMes('<?php echo e($usuario['id']); ?>')">
                          Liquidar Mes
                        </button>
                        
                      </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>

            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row row-cards mt-2">
    <div class="col-12">
      <div class="card">
        <div class="card-body border-bottom pt-3 pb-4">
          
          <div class="row">
            <div class="col">
              <h3>Registros de ingreso y egreso</h3>
            </div>
            <div class="col-md-4 col-sm-5 mt-1">
              <select class="form-select" wire:model="userId" wire:click="resetPagination">
                <option value="0">Todos los Usuarios</option>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($usuario->id); ?>"><?php echo e($usuario->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          
        </div>
        <div class="table-responsive">
          <table class="table table-vcenter card-table">
            <thead>
              <tr>
                <th>Usuario</th>
                <th>Inicio</th>
                <th>Fin</th>
                <th>Horas del Día</th>
                <th>Liquidado</th>
                <th>Comentarios</th>
                <th></th>
              </tr>
            </thead>
            <tbody>

              <?php $__currentLoopData = $horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>

                <td><?php echo e($hora->usuario->name); ?></td>
                <td><?php echo e(date_format(date_create($hora->inicio),"d-m-Y H:i")); ?>

                  <a class="btn btn-ghost-light btn-icon" href="<?php echo e(route('usuarios.ingreso.edit',$hora->id)); ?>"
                    data-toggle="tooltip" data-placement="right" title="Editar">
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-edit" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                      <path d="M7 7h-1a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-1"></path>
                      <path d="M20.385 6.585a2.1 2.1 0 0 0 -2.97 -2.97l-8.415 8.385v3h3l8.385 -8.415z"></path>
                      <path d="M16 5l3 3"></path>
                  </svg>
                  </a>
                </td>
                <td>
                  <?php if($hora->fin): ?>
                  <?php echo e(date_format(date_create($hora->fin),"d-m-Y H:i")); ?>

                  <a class="btn btn-ghost-light btn-icon" href="<?php echo e(route('usuarios.egreso.edit',$hora->id)); ?>"
                    data-toggle="tooltip" data-placement="right" title="Editar">
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-edit" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                      <path d="M7 7h-1a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-1"></path>
                      <path d="M20.385 6.585a2.1 2.1 0 0 0 -2.97 -2.97l-8.415 8.385v3h3l8.385 -8.415z"></path>
                      <path d="M16 5l3 3"></path>
                  </svg>
                  </a>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if($hora->fin): ?>
                  <?php echo e($hora->getHorasTrabajadas()); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <?php if($hora->liquidado): ?>
                  <span class="badge bg-success">Sí</span>
                  <?php else: ?>
                  <span class="badge bg-danger">No</span>
                  <?php endif; ?>
                </td>
                <td><?php echo e($hora->comentarios); ?></td>
                <td>
                  <div class="dropdown">
                    <button class="btn btn-sm btn-dark dropdown-toggle align-text-top" data-bs-boundary="viewport"
                      data-bs-toggle="dropdown">
                      Acciones
                    </button>
                    <div class="dropdown-menu dropdown-menu-end">
                      <?php if($hora->liquidado): ?>
                      <button class="dropdown-item" wire:click="noLiquidado('<?php echo e($hora->id); ?>')">
                        No Liquidado
                      </button>
                      <?php else: ?>
                      <button class="dropdown-item" wire:click="liquidado('<?php echo e($hora->id); ?>')">
                        Liquidado
                      </button>
                      <?php endif; ?>

                    </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

          </table>
          <?php echo e($horas->links()); ?>

        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\laragon\www\doconline\resources\views/livewire/usuarios/horas-trabajadas.blade.php ENDPATH**/ ?>