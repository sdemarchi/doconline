<?php if (isset($component)) { $__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TurneroLayout::class, []); ?>
<?php $component->withName('turnero-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('turnero.panel', [])->html();
} elseif ($_instance->childHasBeenRendered('uP9CAdp')) {
    $componentId = $_instance->getRenderedChildComponentId('uP9CAdp');
    $componentTag = $_instance->getRenderedChildComponentTagName('uP9CAdp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uP9CAdp');
} else {
    $response = \Livewire\Livewire::mount('turnero.panel', []);
    $html = $response->html();
    $_instance->logRenderedChild('uP9CAdp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b)): ?>
<?php $component = $__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b; ?>
<?php unset($__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\doconline\resources\views/turnero/panel.blade.php ENDPATH**/ ?>