<div class="row row-cards">
    <div class="col-12">
      <div class="card">
        <div class="card-body border-bottom py-3">
          <div class="d-flex">
            <div class="ms-auto text-muted">
              <div class="ms-2 d-inline-block">
                <input type="text" class="form-control form-control-sm" placeholder="Buscar Paciente"
                wire:model.defer="searchString" wire:keydown.enter="resetPagination">
              </div>
            </div>
          </div>
        </div>
        <div class="table-responsive">
          <table class="table table-vcenter card-table">
            <thead>
              <tr>
                <th></th>
                <th class="sorting" wire:click="sort('id')">Id
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.sort-icon','data' => ['sortField' => $idSort]]); ?>
<?php $component->withName('sort-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['sortField' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($idSort)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </th>
                <th class="sorting" wire:click="sort('fecha')">Fecha
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.sort-icon','data' => ['sortField' => $fechaSort]]); ?>
<?php $component->withName('sort-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['sortField' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fechaSort)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </th>
                <th class="sorting" wire:click="sort('nombre')">Paciente
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.sort-icon','data' => ['sortField' => $nombreSort]]); ?>
<?php $component->withName('sort-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['sortField' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nombreSort)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </th>
                <th></th>
              </tr>
            </thead>
            <tbody>
  
              <?php $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <a class="btn btn-ghost-light btn-icon" href="<?php echo e(route('recetas.edit',$receta->id)); ?>"
                    data-toggle="tooltip" data-placement="right" title="Editar">
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-edit" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                      <path d="M7 7h-1a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-1"></path>
                      <path d="M20.385 6.585a2.1 2.1 0 0 0 -2.97 -2.97l-8.415 8.385v3h3l8.385 -8.415z"></path>
                      <path d="M16 5l3 3"></path>
                  </svg>
                  </a>
                  <a href="<?php echo e(route('receta.impresion',$receta->id)); ?>" target="_blank"><img src="<?php echo e(asset('img/icon-decl.png')); ?>" width="25"/></a>
                  
                </td>
                <td><?php echo e($receta->id); ?></td>
                <td><?php echo e(date_format(date_create($receta->fecha),"d/m/Y")); ?></td>
                <td><?php echo e($receta->nombre); ?></td>
                <td>
                  <div class="dropdown">
                    <button class="btn btn-sm btn-dark dropdown-toggle align-text-top" data-bs-boundary="viewport"
                      data-bs-toggle="dropdown">
                      Acciones
                    </button>
                    <div class="dropdown-menu dropdown-menu-end">
                        <a class="dropdown-item" href="<?php echo e(route('recetas.edit',$receta->id)); ?>">Editar</a>
                        <button class="dropdown-item" wire:click="$emit('triggerDelete',<?php echo e($receta->id); ?>)">
                          Eliminar
                        </button>
                    </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
            </tbody>
  
          </table>
          <?php echo e($recetas->links()); ?>

        </div>
      </div>
    </div>
  </div>
  
  <?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {
            window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerDelete', itemId => {
                Swal.fire({
                    title: 'Está Seguro?',
                    text: 'Se eliminará la Receta',
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: '#ec536c',
                    cancelButtonColor: '#aaa',
                    cancelButtonText: 'cancelar',
                    confirmButtonText: 'Eliminar!'
                }).then((result) => {
                    if (result.value) {
                
                        window.livewire.find('<?php echo e($_instance->id); ?>').call('eliminar',itemId)
                
                    }
                });
            });
        })
        
    </script>
  
  <?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\doconline\resources\views/livewire/pacientes/recetas.blade.php ENDPATH**/ ?>