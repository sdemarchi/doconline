<?php if (isset($component)) { $__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TurneroLayout::class, []); ?>
<?php $component->withName('turnero-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('turnero.turnos', [])->html();
} elseif ($_instance->childHasBeenRendered('ltAaHwc')) {
    $componentId = $_instance->getRenderedChildComponentId('ltAaHwc');
    $componentTag = $_instance->getRenderedChildComponentTagName('ltAaHwc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ltAaHwc');
} else {
    $response = \Livewire\Livewire::mount('turnero.turnos', []);
    $html = $response->html();
    $_instance->logRenderedChild('ltAaHwc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b)): ?>
<?php $component = $__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b; ?>
<?php unset($__componentOriginale7df8232fd4052371301254548bdfcbc988ace7b); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\doconline\resources\views/turnero/turnos.blade.php ENDPATH**/ ?>