
        
           
<div class="card">
  <div class="card-footer text-end">
      <div class="d-flex">
        <button wire:click="update" class="btn btn-primary ms-auto">Guardar</button>
      </div>
    </div>
    <div class="card-body">
      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <label class="form-label col-3 col-form-label">Apellido y Nombre</label>
            <div class="col">
              <input type="text" class="form-control" wire:model.defer="datos.apeynom">
              <?php $__errorArgs = ['datos.apeynom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <label class="form-label col-3 col-form-label">Tipo y N° Documento</label>
            <div class="col-6">
              <input type="text" class="form-control" wire:model.defer="datos.tipo_nro_doc">
              <?php $__errorArgs = ['datos.tipo_nro_doc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <label class="form-label col-3 col-form-label">Matrícula</label>
            <div class="col-4">
              <input type="text" class="form-control" wire:model.defer="datos.matricula">
              <?php $__errorArgs = ['datos.matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <label class="form-label col-3 col-form-label">Especialidad</label>
            <div class="col-6">
              <input type="text" class="form-control" wire:model.defer="datos.especialidad">
              <?php $__errorArgs = ['datos.especialidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <label class="form-label col-3 col-form-label">Domicilio</label>
            <div class="col">
              <input type="text" class="form-control" wire:model.defer="datos.domicilio">
              <?php $__errorArgs = ['datos.domicilio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <label class="form-label col-3 col-form-label">Teléfono Particular</label>
            <div class="col-4">
              <input type="text" class="form-control" wire:model.defer="datos.tel_part">
              <?php $__errorArgs = ['datos.tel_part'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <label class="form-label col-3 col-form-label">Teléfono Celular</label>
            <div class="col-4">
              <input type="text" class="form-control" wire:model.defer="datos.tel_cel">
              <?php $__errorArgs = ['datos.tel_cel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <label class="form-label col-3 col-form-label">Email</label>
            <div class="col-6">
              <input type="text" class="form-control" wire:model.defer="datos.email">
              <?php $__errorArgs = ['datos.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
      </div>

      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <label class="form-label col-3 col-form-label">Firma</label>
            <div class="col">
              <img src="<?php echo e(asset('/img/uploads/' . $datos->firma)); ?>" height="100"/>
            </div>
          </div>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <div class="col-3"></div>
            <div class="col">
              <input type="file" wire:model="firma">
              <div wire:loading wire:target="firma">Subiendo Archivo...</div>
              <?php $__errorArgs = ['firma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
      </div>

      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <label class="form-label col-3 col-form-label">Sello</label>
            <div class="col">
              <img src="<?php echo e(asset('/img/uploads/' . $datos->sello)); ?>" height="100"/>
            </div>
          </div>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-lg-10">
          <div class="form-group row">
            <div class="col-3"></div>
            <div class="col">
              <input type="file" wire:model="sello">
              <div wire:loading wire:target="sello">Subiendo Archivo...</div>
              <?php $__errorArgs = ['sello'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
    
  
  <?php /**PATH C:\laragon\www\doconline\resources\views/livewire/datos-medico.blade.php ENDPATH**/ ?>