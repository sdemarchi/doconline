<div>
    
        <iframe src="https://reprocann.msal.gob.ar/auth" style="width:100%; height:750px">
        </iframe>
    
</div>
<?php /**PATH C:\laragon\www\doconline\resources\views/livewire/web-reprocann.blade.php ENDPATH**/ ?>